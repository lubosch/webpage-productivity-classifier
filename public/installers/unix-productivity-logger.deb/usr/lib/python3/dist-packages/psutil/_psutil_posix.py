# encoding: utf-8
# module psutil._psutil_posix calls itself psutil_posix
# from /home/fred/.local/lib/python3.4/site-packages/psutil/_psutil_posix.cpython-34m.so
# by generator 1.136
# no doc
# no imports

# functions

def getpriority(*args, **kwargs): # real signature unknown
    """ Return process priority """
    pass

def net_if_addrs(*args, **kwargs): # real signature unknown
    """ Retrieve NICs information """
    pass

def setpriority(*args, **kwargs): # real signature unknown
    """ Set process priority """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

